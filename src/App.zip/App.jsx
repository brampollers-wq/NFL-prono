import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  Trophy,
  Flame,
  Lock,
  Users,
  ClipboardList,
  Shield,
  ChevronLeft,
  ChevronRight,
  AlertCircle,
  Check,
  Trash2,
  Beer,
  UtensilsCrossed,
  KeyRound,
  LogIn,
  Wifi,
  Eye,
  EyeOff,
  ListChecks,
} from "lucide-react";
import { supabase } from "./supabaseClient";

/* ---------------------------------------------------------------
   Constants & helpers
--------------------------------------------------------------- */

const TEAMS = [
  "Arizona Cardinals","Atlanta Falcons","Baltimore Ravens","Buffalo Bills",
  "Carolina Panthers","Chicago Bears","Cincinnati Bengals","Cleveland Browns",
  "Dallas Cowboys","Denver Broncos","Detroit Lions","Green Bay Packers",
  "Houston Texans","Indianapolis Colts","Jacksonville Jaguars","Kansas City Chiefs",
  "Las Vegas Raiders","Los Angeles Chargers","Los Angeles Rams","Miami Dolphins",
  "Minnesota Vikings","New England Patriots","New Orleans Saints","New York Giants",
  "New York Jets","Philadelphia Eagles","Pittsburgh Steelers","San Francisco 49ers",
  "Seattle Seahawks","Tampa Bay Buccaneers","Tennessee Titans","Washington Commanders",
];

const PERIODS = [
  { id: 1, label: "Week 1 t/m 6", min: 1, max: 6 },
  { id: 2, label: "Week 7 t/m 12", min: 7, max: 12 },
  { id: 3, label: "Week 13 t/m 18", min: 13, max: 18 },
];

// Primaire clubkleur per team — gebruikt om de accentkleur van de app te
// personaliseren op basis van het rooting team van de ingelogde speler.
const TEAM_COLORS = {
  "Arizona Cardinals": "#97233F",
  "Atlanta Falcons": "#A71930",
  "Baltimore Ravens": "#241773",
  "Buffalo Bills": "#00338D",
  "Carolina Panthers": "#0085CA",
  "Chicago Bears": "#C83803",
  "Cincinnati Bengals": "#FB4F14",
  "Cleveland Browns": "#FF3C00",
  "Dallas Cowboys": "#003594",
  "Denver Broncos": "#FB4F14",
  "Detroit Lions": "#0076B6",
  "Green Bay Packers": "#FFB612",
  "Houston Texans": "#A71930",
  "Indianapolis Colts": "#002C5F",
  "Jacksonville Jaguars": "#006778",
  "Kansas City Chiefs": "#E31837",
  "Las Vegas Raiders": "#A5ACAF",
  "Los Angeles Chargers": "#0080C6",
  "Los Angeles Rams": "#FFA300",
  "Miami Dolphins": "#008E97",
  "Minnesota Vikings": "#4F2683",
  "New England Patriots": "#C60C30",
  "New Orleans Saints": "#D3BC8D",
  "New York Giants": "#0B2265",
  "New York Jets": "#125740",
  "Philadelphia Eagles": "#004C54",
  "Pittsburgh Steelers": "#FFB612",
  "San Francisco 49ers": "#AA0000",
  "Seattle Seahawks": "#69BE28",
  "Tampa Bay Buccaneers": "#D50A0A",
  "Tennessee Titans": "#4B92DB",
  "Washington Commanders": "#5A1414",
};

// Secundaire clubkleur per team — gebruikt voor de achtergrondtint, zodat
// die niet gewoon een verdonkerde versie van de accentkleur is maar een
// écht tweede kleuraccent (zoals de meeste clubs zelf een kleurenpaar
// hebben, bv. Broncos oranje + navy, Eagles groen + zilver).
const TEAM_SECONDARY_COLORS = {
  "Arizona Cardinals": "#000000",
  "Atlanta Falcons": "#000000",
  "Baltimore Ravens": "#000000",
  "Buffalo Bills": "#C60C30",
  "Carolina Panthers": "#000000",
  "Chicago Bears": "#0B162A",
  "Cincinnati Bengals": "#000000",
  "Cleveland Browns": "#311D00",
  "Dallas Cowboys": "#869397",
  "Denver Broncos": "#002244",
  "Detroit Lions": "#B0B7BC",
  "Green Bay Packers": "#203731",
  "Houston Texans": "#03202F",
  "Indianapolis Colts": "#A2AAAD",
  "Jacksonville Jaguars": "#101820",
  "Kansas City Chiefs": "#FFB81C",
  "Las Vegas Raiders": "#000000",
  "Los Angeles Chargers": "#002A5E",
  "Los Angeles Rams": "#003594",
  "Miami Dolphins": "#005778",
  "Minnesota Vikings": "#FFC62F",
  "New England Patriots": "#C60C30",
  "New Orleans Saints": "#101820",
  "New York Giants": "#A71930",
  "New York Jets": "#000000",
  "Philadelphia Eagles": "#A5ACAF",
  "Pittsburgh Steelers": "#101820",
  "San Francisco 49ers": "#B3995D",
  "Seattle Seahawks": "#002244",
  "Tampa Bay Buccaneers": "#34302B",
  "Tennessee Titans": "#0C2340",
  "Washington Commanders": "#FFB612",
};

// Derde/tertiaire clubkleur per team — gebruikt als "highlight"-kleur voor
// randen/lijnen, zodat de personalisatie écht als een drieklank aanvoelt
// (zoals de meeste clubs zelf een drieluik van kleuren hanteren) i.p.v.
// enkel accent + achtergrond. Teams zonder een echt onderscheidende derde
// merkkleur (vaak is die gewoon wit) vallen terug op een neutrale grijstint.
const TERTIARY_FALLBACK = "#9CA3AF";
const TEAM_TERTIARY_COLORS = {
  "Arizona Cardinals": TERTIARY_FALLBACK,
  "Atlanta Falcons": "#A5ACAF",
  "Baltimore Ravens": "#9E7C0C",
  "Buffalo Bills": TERTIARY_FALLBACK,
  "Carolina Panthers": "#BFC0BF",
  "Chicago Bears": TERTIARY_FALLBACK,
  "Cincinnati Bengals": TERTIARY_FALLBACK,
  "Cleveland Browns": TERTIARY_FALLBACK,
  "Dallas Cowboys": TERTIARY_FALLBACK,
  "Denver Broncos": TERTIARY_FALLBACK,
  "Detroit Lions": "#000000",
  "Green Bay Packers": TERTIARY_FALLBACK,
  "Houston Texans": TERTIARY_FALLBACK,
  "Indianapolis Colts": TERTIARY_FALLBACK,
  "Jacksonville Jaguars": "#D7A22A",
  "Kansas City Chiefs": TERTIARY_FALLBACK,
  "Las Vegas Raiders": TERTIARY_FALLBACK,
  "Los Angeles Chargers": "#FFC20E",
  "Los Angeles Rams": TERTIARY_FALLBACK,
  "Miami Dolphins": "#FC4C02",
  "Minnesota Vikings": TERTIARY_FALLBACK,
  "New England Patriots": "#B0B7BC",
  "New Orleans Saints": TERTIARY_FALLBACK,
  "New York Giants": "#A5ACAF",
  "New York Jets": TERTIARY_FALLBACK,
  "Philadelphia Eagles": "#000000",
  "Pittsburgh Steelers": TERTIARY_FALLBACK,
  "San Francisco 49ers": "#000000",
  "Seattle Seahawks": "#A5ACAF",
  "Tampa Bay Buccaneers": "#FF7900",
  "Tennessee Titans": "#C8102E",
  "Washington Commanders": "#000000",
};

// Standaard accent (amber) — gebruikt vóór aanmelden, of als een rooting
// team toevallig geen kleur in de tabel heeft.
const DEFAULT_ACCENT = "#fbbf24";

function hexToRgb(hex) {
  const clean = hex.replace("#", "");
  const bigint = parseInt(clean, 16);
  return { r: (bigint >> 16) & 255, g: (bigint >> 8) & 255, b: bigint & 255 };
}

function mixWith(hex, targetHex, amount) {
  const a = hexToRgb(hex);
  const b = hexToRgb(targetHex);
  const mix = (x, y) => Math.round(x + (y - x) * amount);
  return `rgb(${mix(a.r, b.r)}, ${mix(a.g, b.g)}, ${mix(a.b, b.b)})`;
}

function rgba(hex, alpha) {
  const { r, g, b } = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function hexToHsl(hex) {
  let { r, g, b } = hexToRgb(hex);
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      default:
        h = (r - g) / d + 4;
    }
    h /= 6;
  }
  return { h: h * 360, s: s * 100, l: l * 100 };
}

function hslToHex(h, s, l) {
  s /= 100;
  l /= 100;
  const k = (n) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  const toHex = (x) => Math.round(255 * x).toString(16).padStart(2, "0");
  return `#${toHex(f(0))}${toHex(f(8))}${toHex(f(4))}`;
}

// Zet een kleur om naar een specifieke helderheid (en optioneel een
// verzadigingsvenster), met behoud van de oorspronkelijke tint (hue) — puur
// zwart of wit bijmengen (zoals mixWith) doet verschillende clubkleuren
// allemaal naar hetzelfde grijs convergeren. Door in HSL te werken en enkel
// de helderheid te sturen, blijft elk team zijn eigen herkenbare kleurtint
// houden, of die nu heel donker of heel fel moet worden.
function toneFrom(hex, lightness, { minS = 0, maxS = 78 } = {}) {
  const { h, s } = hexToHsl(hex);
  const clampedSaturation = Math.max(minS, Math.min(s, maxS));
  return hslToHex(h, clampedSaturation, lightness);
}

// Zwart of wit tekst, naargelang wat het meeste contrast geeft op de
// accentkleur (relatieve luminantie, WCAG-achtige benadering).
function contrastText(hex) {
  const { r, g, b } = hexToRgb(hex);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.6 ? "#0c0a09" : "#ffffff";
}

// Relatieve luminantie zoals WCAG die berekent — dit is een betere maat voor
// hoe "licht" een kleur oogt dan de HSL-helderheid, want bij eenzelfde
// HSL-helderheid oogt blauw/paars veel donkerder dan geel/oranje (het
// menselijk oog is veel gevoeliger voor groen dan voor blauw).
function relLuminance(hex) {
  const { r, g, b } = hexToRgb(hex);
  const lin = (c) => {
    c /= 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
}

// Zoekt, voor een vaste tint/verzadiging, de HSL-helderheid die een gewenste
// relatieve luminantie oplevert. Hierdoor krijgen alle teams — ongeacht of
// hun clubkleur van zichzelf donker (Ravens-paars) of licht (Steelers-goud)
// is — een even fel/leesbaar resultaat, in plaats van dat sommige teams per
// ongeluk op een veel te donkere of te lichte tint uitkomen.
function hslForLuminance(h, s, targetLuminance) {
  let lo = 0;
  let hi = 100;
  for (let i = 0; i < 20; i++) {
    const mid = (lo + hi) / 2;
    const candidate = hslToHex(h, s, mid);
    if (relLuminance(candidate) < targetLuminance) lo = mid;
    else hi = mid;
  }
  return hslToHex(h, s, (lo + hi) / 2);
}

// Doelluminanties voor de donkere achtergrondlagen en de lichte tekstlagen
// — zo gekozen dat er altijd een stevig contrast zit tussen tekst en
// achtergrond, voor elk team, ongeacht de tint van de clubkleuren.
const BG_DARK_LUMINANCE = 0.045;
const BG_PANEL_LUMINANCE = 0.075;
const TEXT_STRONG_LUMINANCE = 0.85;
const TEXT_SOFT_LUMINANCE = 0.5;
const HIGHLIGHT_LUMINANCE = 0.55;

// Berekent alle CSS-variabelen voor de kleurpersonalisatie op basis van een
// rooting team. Opzet: een donkere achtergrond (afgeleid van de secundaire
// clubkleur, bv. Broncos-navy) met de felle hoofdkleur van het team als
// accent voor knoppen/badges/actieve elementen — de felle kleur zelf als
// volledige paginaKleur bleek in de praktijk te onrustig en te weinig
// leesbaar, dus dit is bewust weer de "donkere achtergrond + felle accent"
// opzet. De tekstkleuren krijgen wel een lichte, subtiele tint van diezelfde
// donkere clubkleur mee (i.p.v. helemaal neutraal wit), voor een beetje
// extra personalisatie zonder de leesbaarheid in gevaar te brengen. De
// helderheid van elke laag wordt via relLuminance/hslForLuminance bepaald
// (niet zomaar een vaste HSL-waarde), zodat elk team — of de clubkleur nu
// van zichzelf donker (Ravens-paars) of licht (Packers-goud) is — op een
// consistente, goed leesbare donkerte/felheid uitkomt.
function accentVarsForTeam(teamName) {
  const primary = TEAM_COLORS[teamName] || DEFAULT_ACCENT;
  // Donkere/secundaire clubkleur (bv. Broncos-navy, Steelers-zwart) — de
  // basis voor de achtergrond én voor een lichte tint in de tekstkleuren.
  const dark = TEAM_SECONDARY_COLORS[teamName] || "#1c1917";
  // Derde kleur, gebruikt als aparte "highlight" voor randen/lijnen door de
  // hele app — zo voelt de personalisatie echt als een drieklank i.p.v.
  // enkel accent + achtergrond.
  const highlightBase = TEAM_TERTIARY_COLORS[teamName] || TERTIARY_FALLBACK;

  // Donkere achtergrond op basis van de secundaire clubkleur.
  const { h: darkHue, s: darkSatRaw } = hexToHsl(dark);
  const darkSat = Math.max(0, Math.min(darkSatRaw, 80));
  const bgDark = hslForLuminance(darkHue, darkSat, BG_DARK_LUMINANCE);
  const bgPanel = hslForLuminance(darkHue, darkSat, BG_PANEL_LUMINANCE);

  // Lichte tekstkleuren met een subtiele tint van de donkere clubkleur.
  const textStrong = hslForLuminance(darkHue, Math.min(darkSat, 20), TEXT_STRONG_LUMINANCE);
  const textSoft = hslForLuminance(darkHue, Math.min(darkSat, 30), TEXT_SOFT_LUMINANCE);

  // Felle hoofdkleur van het team = accentkleur voor knoppen/badges.
  const accentBg = primary;

  const { h: highlightHue, s: highlightSatRaw } = hexToHsl(highlightBase);
  const highlightSat = Math.max(30, Math.min(highlightSatRaw, 85));
  const highlight = hslForLuminance(highlightHue, highlightSat, HIGHLIGHT_LUMINANCE);

  return {
    "--accent": accentBg,
    "--accent-hover": mixWith(accentBg, "#ffffff", 0.2),
    "--accent-border": mixWith(accentBg, "#000000", 0.25),
    "--accent-soft": rgba(accentBg, 0.15),
    "--accent-text": contrastText(accentBg),
    "--bg-dark": bgDark,
    "--bg-panel": bgPanel,
    "--text-strong": textStrong,
    "--text-soft": textSoft,
    "--highlight": highlight,
    "--highlight-soft": rgba(highlightBase, 0.4),
  };
}

function periodForWeek(weekNum) {
  const p = PERIODS.find((p) => weekNum >= p.min && weekNum <= p.max);
  return p ? p.id : null;
}

// Vaste groepstoegangscode — zie ook SETUP.md om dit te wijzigen.
const APP_ACCESS_CODE = "NFL2026";

// Aantal spelers dat hun double point game op deze specifieke wedstrijd
// heeft gezet. Zodra minstens 1 speler dat doet, telt de wedstrijd voor
// IEDEREEN dubbel (x2) — niet enkel voor die ene speler. Zetten 2 spelers
// (onafhankelijk van elkaar) hun DPG op dezelfde wedstrijd, dan geldt x4
// voor alle spelers op die wedstrijd. Het reglement laat max 2 double point
// games per week toe (over alle spelers samen), dus meer dan x4 kan sowieso
// niet voorkomen.
//
// Daarnaast kan een wedstrijd een AUTOMATISCHE double point game zijn
// (games.auto_double, bv. de Londense wedstrijd Eagles-Jaguars in week 5):
// die telt altijd als 1 extra verdubbeling voor iedereen, los van wat spelers
// zelf inzetten. Zet een speler daar ook nog zijn eigen DPG op, dan stapelt
// dat (x2 automatisch + x2 speler = x4). Die automatische DPG telt niet mee
// voor de limiet van 2 spelers-DPG's per week.
function playerDoubleCount(allPicks, gameId) {
  return allPicks.filter((p) => p.game_id === gameId && p.is_double).length;
}

function doubleCountForGame(allPicks, game) {
  return playerDoubleCount(allPicks, game.id) + (game.auto_double ? 1 : 0);
}

function computeGamePoints(pickedTeam, game, doubleCount = 0) {
  if (game.home_score === null || game.home_score === undefined) return null;
  const { home_score: homeScore, away_score: awayScore, home_team: home, away_team: away } = game;
  if (homeScore === awayScore) return 0;
  const winner = homeScore > awayScore ? home : away;
  const margin = Math.abs(homeScore - awayScore);
  let pts;
  if (pickedTeam === winner) pts = margin >= 10 ? 4 : 2;
  else pts = margin >= 10 ? 0 : 1;
  if (doubleCount <= 0) return pts;
  const multiplier = Math.pow(2, doubleCount);
  return pts * multiplier;
}

function fmtDeadline(iso) {
  if (!iso) return "geen deadline ingesteld";
  return new Date(iso).toLocaleString("nl-BE", {
    weekday: "short",
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function isLocked(week) {
  if (!week?.deadline) return false;
  return new Date() >= new Date(week.deadline);
}

function fmtKickoff(iso) {
  if (!iso) return null;
  return new Date(iso).toLocaleString("nl-BE", {
    weekday: "short",
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/* ---------------------------------------------------------------
   Main App
--------------------------------------------------------------- */

export default function App() {
  const [unlocked, setUnlocked] = useState(() => localStorage.getItem("unlocked") === "true");
  const [players, setPlayers] = useState([]);
  const [weeks, setWeeks] = useState([]);
  const [games, setGames] = useState([]);
  const [picks, setPicks] = useState([]);
  const [rootingResults, setRootingResults] = useState([]);
  const [myPlayerId, setMyPlayerId] = useState(() => localStorage.getItem("myPlayerId") || null);
  const [tab, setTab] = useState("picks");
  const [activeWeek, setActiveWeek] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [toast, setToast] = useState(null);
  const channelRef = useRef(null);

  useEffect(() => {
    if (!unlocked) return;
    loadAll();
    subscribeRealtime();
    return () => {
      if (channelRef.current) supabase.removeChannel(channelRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unlocked]);

  // Personaliseert de accentkleur van de app op basis van het rooting team
  // van de ingelogde speler (valt terug op amber zolang niemand is aangemeld).
  useEffect(() => {
    const me = players.find((p) => p.id === myPlayerId) || null;
    const vars = accentVarsForTeam(me?.rooting_team);
    for (const [key, value] of Object.entries(vars)) {
      document.documentElement.style.setProperty(key, value);
    }
  }, [players, myPlayerId]);

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  }

  async function loadAll() {
    setLoading(true);
    try {
      const [playersRes, weeksRes, gamesRes, picksRes, rootingRes] = await Promise.all([
        supabase.from("players").select("*"),
        supabase.from("weeks").select("*").order("week_num"),
        supabase.from("games").select("*"),
        supabase.from("picks").select("*"),
        supabase.from("rooting_results").select("*"),
      ]);
      if (playersRes.error) throw playersRes.error;
      if (weeksRes.error) throw weeksRes.error;
      if (gamesRes.error) throw gamesRes.error;
      if (picksRes.error) throw picksRes.error;
      if (rootingRes.error) throw rootingRes.error;

      setPlayers(playersRes.data);
      setWeeks(weeksRes.data);
      setGames(gamesRes.data);
      setPicks(picksRes.data);
      setRootingResults(rootingRes.data);

      const weekNums = weeksRes.data.map((w) => w.week_num);
      if (weekNums.length) setActiveWeek(Math.max(...weekNums));
    } catch (e) {
      setError("Kon de gegevens niet laden: " + e.message);
    }
    setLoading(false);
  }

  function subscribeRealtime() {
    const channel = supabase
      .channel("pronostiek-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "games" }, loadAll)
      .on("postgres_changes", { event: "*", schema: "public", table: "picks" }, loadAll)
      .on("postgres_changes", { event: "*", schema: "public", table: "rooting_results" }, loadAll)
      .on("postgres_changes", { event: "*", schema: "public", table: "weeks" }, loadAll)
      .subscribe();
    channelRef.current = channel;
  }

  function unlock() {
    localStorage.setItem("unlocked", "true");
    setUnlocked(true);
  }

  function loginAs(id) {
    localStorage.setItem("myPlayerId", id);
    setMyPlayerId(id);
  }

  function logout() {
    localStorage.removeItem("myPlayerId");
    setMyPlayerId(null);
  }

  async function registerPlayer({ name, championshipTeam, rootingTeam, pin }) {
    const { data, error: insertError } = await supabase
      .from("players")
      .insert({ name, championship_team: championshipTeam, rooting_team: rootingTeam, pin })
      .select()
      .single();
    if (insertError) {
      showToast(
        insertError.code === "23505" ? "Die naam bestaat al, kies een andere." : "Aanmelden mislukt."
      );
      return;
    }
    setPlayers((prev) => [...prev, data]);
    loginAs(data.id);
    showToast(`Welkom, ${data.name}!`);
  }

  async function savePicks(weekNum, gamePicksMap, doubleGameId) {
    if (!myPlayerId) return;
    const rows = Object.entries(gamePicksMap).map(([gameId, team]) => ({
      week_num: weekNum,
      player_id: myPlayerId,
      game_id: gameId,
      picked_team: team,
      is_double: gameId === doubleGameId,
    }));
    const { error: upsertError } = await supabase
      .from("picks")
      .upsert(rows, { onConflict: "player_id,game_id" });
    if (upsertError) {
      if (upsertError.message?.includes("uniq_double_per_player_per_period")) {
        showToast(
          "Je hebt je double point game voor deze periode (van 6 weken) al gebruikt in een andere week."
        );
      } else if (upsertError.message?.includes("uniq_double_per_player_per_week")) {
        showToast("Je kan maar 1 double point game per week selecteren.");
      } else if (upsertError.message?.includes("max_2_double_point_games_per_week")) {
        showToast(
          "Er zijn deze week al 2 double point games ingezet door andere spelers — dat is het maximum per week."
        );
      } else {
        showToast("Opslaan van picks is mislukt: " + upsertError.message);
      }
      return;
    }
    await loadAll();
    showToast("Picks opgeslagen!");
  }

  async function adminSaveResult(gameId, homeScore, awayScore) {
    const { error: updateError } = await supabase
      .from("games")
      .update({ home_score: Number(homeScore), away_score: Number(awayScore), status: "final" })
      .eq("id", gameId);
    if (updateError) showToast("Opslaan mislukt: " + updateError.message);
    else await loadAll();
  }

  async function adminSaveRooting(weekNum, team, outcome) {
    if (!outcome) {
      // "– (nog niet bekend)" gekozen: gewoon de rij verwijderen i.p.v. een
      // lege waarde op te slaan (die zou de check-constraint schenden).
      const { error: deleteError } = await supabase
        .from("rooting_results")
        .delete()
        .eq("week_num", weekNum)
        .eq("team", team);
      if (deleteError) showToast("Verwijderen mislukt: " + deleteError.message);
      else await loadAll();
      return;
    }
    const { error: upsertError } = await supabase
      .from("rooting_results")
      .upsert({ week_num: weekNum, team, outcome }, { onConflict: "week_num,team" });
    if (upsertError) showToast("Opslaan mislukt: " + upsertError.message);
    else await loadAll();
  }

  async function adminAddWeek(weekNum, deadline, draftGames) {
    const { error: weekError } = await supabase
      .from("weeks")
      .upsert({ week_num: weekNum, deadline: deadline ? new Date(deadline).toISOString() : null });
    if (weekError) {
      showToast("Opslaan van week mislukt: " + weekError.message);
      return;
    }
    const rows = draftGames.map((g) => ({
      week_num: weekNum,
      home_team: g.home,
      away_team: g.away,
      spread: g.spread || null,
      status: "scheduled",
    }));
    const { error: gamesError } = await supabase.from("games").insert(rows);
    if (gamesError) {
      showToast("Opslaan van wedstrijden mislukt: " + gamesError.message);
      return;
    }
    await loadAll();
    setActiveWeek(Number(weekNum));
    showToast(`Week ${weekNum} opgeslagen.`);
  }

  async function removePlayer(id) {
    const { error: deleteError } = await supabase.from("players").delete().eq("id", id);
    if (deleteError) showToast("Verwijderen mislukt: " + deleteError.message);
    else await loadAll();
  }

  if (!unlocked) return <AccessGate onUnlock={unlock} />;

  if (loading) {
    return (
      <div className="min-h-screen bg-emerald-950 flex items-center justify-center text-emerald-100">
        Bezig met laden…
      </div>
    );
  }

  const weekNums = weeks.map((w) => w.week_num).sort((a, b) => a - b);
  const currentWeek = weeks.find((w) => w.week_num === activeWeek) || null;
  const weekGames = games
    .filter((g) => g.week_num === activeWeek)
    .sort((a, b) => {
      if (!a.commence_time) return 1;
      if (!b.commence_time) return -1;
      return new Date(a.commence_time) - new Date(b.commence_time);
    });
  const me = players.find((p) => p.id === myPlayerId) || null;
  const rootingTeams = Array.from(new Set(players.map((p) => p.rooting_team).filter(Boolean))).sort();

  return (
    <div className="min-h-screen bg-[var(--bg-dark)] text-[var(--text-strong)] pb-16">
      <Header
        weekNums={weekNums}
        activeWeek={activeWeek}
        setActiveWeek={setActiveWeek}
        me={me}
        onLogout={logout}
      />

      <nav className="max-w-3xl mx-auto flex gap-1 px-4 mt-4 border-b border-[var(--highlight-soft)] overflow-x-auto flex-nowrap">
        <TabButton icon={<ClipboardList size={16} />} label="Picks" active={tab === "picks"} onClick={() => setTab("picks")} />
        <TabButton icon={<Eye size={16} />} label="Overzicht" active={tab === "overzicht"} onClick={() => setTab("overzicht")} />
        <TabButton icon={<ListChecks size={16} />} label="Punten" active={tab === "punten"} onClick={() => setTab("punten")} />
        <TabButton icon={<Trophy size={16} />} label="Stand" active={tab === "stand"} onClick={() => setTab("stand")} />
        <TabButton icon={<Shield size={16} />} label="Reglement" active={tab === "reglement"} onClick={() => setTab("reglement")} />
        <TabButton icon={<Users size={16} />} label="Beheer" active={tab === "beheer"} onClick={() => setTab("beheer")} />
      </nav>

      <main className="max-w-3xl mx-auto px-4 mt-6">
        {error && (
          <div className="mb-4 flex items-center gap-2 bg-red-950 border border-red-800 text-red-200 text-sm px-3 py-2 rounded">
            <AlertCircle size={16} />
            {error}
          </div>
        )}

        {tab === "picks" && (
          <PicksTab
            week={currentWeek}
            weekGames={weekGames}
            weekNum={activeWeek}
            players={players}
            me={me}
            picks={picks}
            savePicks={savePicks}
            onRegister={registerPlayer}
            onLogin={loginAs}
            showToast={showToast}
          />
        )}

        {tab === "overzicht" && (
          <OverzichtTab week={currentWeek} weekGames={weekGames} weekNum={activeWeek} players={players} picks={picks} />
        )}

        {tab === "punten" && (
          <PuntenTab
            week={currentWeek}
            weekGames={weekGames}
            weekNum={activeWeek}
            players={players}
            me={me}
            picks={picks}
            rootingResults={rootingResults}
          />
        )}

        {tab === "stand" && (
          <StandTab players={players} weeks={weeks} games={games} picks={picks} rootingResults={rootingResults} />
        )}

        {tab === "reglement" && <ReglementTab />}

        {tab === "beheer" && (
          <BeheerTab
            weeks={weeks}
            games={games}
            players={players}
            picks={picks}
            activeWeek={activeWeek}
            rootingTeams={rootingTeams}
            rootingResults={rootingResults}
            onAddWeek={adminAddWeek}
            onSaveResult={adminSaveResult}
            onSaveRooting={adminSaveRooting}
            onRemovePlayer={removePlayer}
            showToast={showToast}
          />
        )}
      </main>

      <div className="fixed bottom-4 right-4 flex items-center gap-1.5 text-xs text-[var(--text-soft)]">
        <Wifi size={13} /> live verbonden
      </div>

      {toast && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-[var(--accent)] text-[var(--accent-text)] font-semibold text-sm px-4 py-2 rounded shadow-lg">
          {toast}
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------
   Access gate
--------------------------------------------------------------- */

function AccessGate({ onUnlock }) {
  const [input, setInput] = useState("");
  const [error, setError] = useState("");

  function submit() {
    if (input.trim() === APP_ACCESS_CODE) onUnlock();
    else setError("Foute toegangscode.");
  }

  return (
    <div className="min-h-screen bg-emerald-950 text-emerald-50 flex items-center justify-center px-4">
      <div className="w-full max-w-sm border border-[var(--highlight-soft)] rounded-md p-6 bg-[var(--bg-panel)]/60">
        <div className="flex items-center gap-2 mb-1">
          <KeyRound size={18} className="text-[var(--accent)]" />
          <h1 style={{ fontFamily: "'Bebas Neue', sans-serif" }} className="text-2xl text-[var(--accent)]">
            NFL Pronostiek
          </h1>
        </div>
        <p className="text-sm text-[var(--text-soft)] mb-4">Voer de groepstoegangscode in om verder te gaan.</p>
        <input
          type="password"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder="Toegangscode"
          className="w-full bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm mb-2"
          autoFocus
        />
        {error && <p className="text-red-400 text-xs mb-2">{error}</p>}
        <button
          onClick={submit}
          className="w-full bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-[var(--accent-text)] font-semibold text-sm py-2.5 rounded"
        >
          Ontgrendelen
        </button>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   Header & tabs
--------------------------------------------------------------- */

function Header({ weekNums, activeWeek, setActiveWeek, me, onLogout }) {
  const idx = weekNums.indexOf(activeWeek);
  return (
    <header className="border-b border-[var(--highlight-soft)] bg-[var(--bg-panel)]/70">
      <div className="max-w-3xl mx-auto px-4 py-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 style={{ fontFamily: "'Bebas Neue', sans-serif", letterSpacing: "0.03em" }} className="text-4xl text-[var(--accent)] leading-none">
            NFL Pronostiek
          </h1>
          <p className="text-[var(--text-soft)] text-sm mt-1">
            {me ? (
              <>
                Ingelogd als <span className="text-[var(--text-strong)] font-medium">{me.name}</span>{" "}
                <button onClick={onLogout} className="underline text-[var(--text-soft)] hover:text-[var(--accent)] ml-1">
                  (wissel speler)
                </button>
              </>
            ) : (
              "Nog niet geregistreerd"
            )}
          </p>
        </div>
        {weekNums.length > 0 && (
          <div className="flex items-center gap-2">
            <button
              disabled={idx <= 0}
              onClick={() => setActiveWeek(weekNums[idx - 1])}
              className="p-1.5 rounded border border-[var(--highlight)]/60 disabled:opacity-30 hover:bg-emerald-800"
            >
              <ChevronLeft size={16} />
            </button>
            <div style={{ fontFamily: "'Bebas Neue', sans-serif" }} className="text-2xl w-24 text-center text-[var(--text-strong)] border border-[var(--highlight)]/60 rounded px-2 py-0.5">
              Week {activeWeek}
            </div>
            <button
              disabled={idx >= weekNums.length - 1}
              onClick={() => setActiveWeek(weekNums[idx + 1])}
              className="p-1.5 rounded border border-[var(--highlight)]/60 disabled:opacity-30 hover:bg-emerald-800"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

function TabButton({ icon, label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={
        "flex items-center gap-1.5 text-sm px-3 py-2 border-b-2 -mb-px transition-colors whitespace-nowrap shrink-0 " +
        (active ? "border-[var(--accent)] text-[var(--accent)]" : "border-transparent text-[var(--text-soft)] hover:text-[var(--text-strong)]")
      }
    >
      {icon}
      {label}
    </button>
  );
}

/* ---------------------------------------------------------------
   Picks tab
--------------------------------------------------------------- */

function PicksTab({ week, weekGames, weekNum, players, me, picks, savePicks, onRegister, onLogin, showToast }) {
  const myExistingPicks = (me && picks.filter((p) => p.week_num === weekNum && p.player_id === me.id)) || [];
  const initialMap = {};
  let initialDouble = null;
  for (const p of myExistingPicks) {
    initialMap[p.game_id] = p.picked_team;
    if (p.is_double) initialDouble = p.game_id;
  }

  const [gamePicks, setGamePicks] = useState(initialMap);
  const [doubleGameId, setDoubleGameId] = useState(initialDouble);

  useEffect(() => {
    const map = {};
    let dbl = null;
    for (const p of picks.filter((x) => x.week_num === weekNum && x.player_id === me?.id)) {
      map[p.game_id] = p.picked_team;
      if (p.is_double) dbl = p.game_id;
    }
    setGamePicks(map);
    setDoubleGameId(dbl);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [weekNum, me?.id]);

  if (!week || weekGames.length === 0) {
    return (
      <EmptyState
        title="Geen wedstrijden voor deze week"
        body="De wekelijkse selectie draait elke woensdag automatisch. Nog niets te zien? Kijk bij Beheer of er iets manueel moet worden toegevoegd."
      />
    );
  }

  if (!me) return <PlayerGate players={players} onRegister={onRegister} onLogin={onLogin} showToast={showToast} />;

  const locked = isLocked(week);
  const period = periodForWeek(weekNum);
  const allPicked = weekGames.every((g) => gamePicks[g.id]);

  let periodUsedElsewhere = false;
  if (period) {
    const myDoubles = picks.filter((p) => p.player_id === me.id && p.is_double && p.week_num !== weekNum);
    periodUsedElsewhere = myDoubles.some((p) => periodForWeek(p.week_num) === period);
  }

  // Reglement: max 2 double point games per week, over alle spelers samen.
  // Als 2 ANDERE spelers deze week al hun DPG hebben ingezet, kan ik enkel
  // nog mijn eigen, al gekozen wedstrijd aan-/uitzetten, maar geen nieuwe.
  const othersWithDoubleThisWeek = new Set(
    picks.filter((p) => p.week_num === weekNum && p.is_double && p.player_id !== me.id).map((p) => p.player_id)
  ).size;
  const weeklyCapReached = othersWithDoubleThisWeek >= 2;

  function selectPick(gameId, team) {
    if (locked) return;
    setGamePicks((prev) => ({ ...prev, [gameId]: team }));
  }

  function toggleDouble(gameId) {
    if (locked || !allPicked || periodUsedElsewhere || !period) return;
    if (weeklyCapReached && doubleGameId !== gameId) return;
    setDoubleGameId((prev) => (prev === gameId ? null : gameId));
  }

  function submit() {
    if (!allPicked) {
      showToast("Kies eerst een winnaar voor elke wedstrijd.");
      return;
    }
    savePicks(weekNum, gamePicks, doubleGameId);
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div className="text-sm text-[var(--text-soft)] flex items-center gap-1.5">
          {locked ? <Lock size={14} /> : null}
          Deadline: <span className="text-[var(--text-strong)]">{fmtDeadline(week.deadline)}</span>
        </div>
        {period && (
          <div className={"text-xs px-2 py-1 rounded border " + (periodUsedElsewhere ? "border-[var(--highlight-soft)] text-[var(--text-soft)]" : "border-[var(--accent-border)] text-[var(--accent)]")}>
            Dubbele-puntenvenster: {PERIODS.find((p) => p.id === period).label}
            {periodUsedElsewhere ? " (al gebruikt)" : ""}
            {!periodUsedElsewhere && weeklyCapReached && !doubleGameId
              ? " — max 2 DPG's deze week al bereikt door anderen"
              : ""}
          </div>
        )}
      </div>

      {locked && (
        <div className="mb-4 text-sm bg-[var(--bg-panel)]/90 border border-[var(--highlight-soft)] rounded px-3 py-2 text-[var(--text-soft)]">
          De deadline voor deze week is verstreken.
        </div>
      )}

      <div className="space-y-3">
        {weekGames.map((g, idx) => (
          <div key={g.id} className="border border-[var(--highlight-soft)] rounded-md p-3 bg-[var(--bg-panel)]/60">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-[var(--text-strong)] font-medium">
                Wedstrijd {idx + 1}: {g.away_team} @ {g.home_team}
                {g.auto_double && (
                  <span
                    className="ml-2 inline-flex items-center gap-0.5 text-xs text-[var(--accent)] align-middle"
                    title="Automatische double point game: deze wedstrijd telt voor iedereen dubbel"
                  >
                    <Flame size={12} /> automatisch 2x
                  </span>
                )}
              </span>
              {g.commence_time && (
                <span className="text-xs text-[var(--text-soft)]">{fmtKickoff(g.commence_time)}</span>
              )}
            </div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-[var(--text-soft)]">{g.spread ? `Spread: ${g.spread}` : "Geen spread"}</span>
              <button
                onClick={() => toggleDouble(g.id)}
                disabled={
                  locked ||
                  !allPicked ||
                  periodUsedElsewhere ||
                  !period ||
                  (weeklyCapReached && doubleGameId !== g.id)
                }
                className={
                  "flex items-center gap-1 text-xs px-2 py-1 rounded border disabled:opacity-30 " +
                  (doubleGameId === g.id ? "bg-[var(--accent)] text-[var(--accent-text)] border-[var(--accent)]" : "border-[var(--highlight)]/60 text-[var(--text-soft)] hover:border-[var(--accent-hover)]")
                }
              >
                <Flame size={13} />
                2x punten
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[g.away_team, g.home_team].map((team) => (
                <button
                  key={team}
                  disabled={locked}
                  onClick={() => selectPick(g.id, team)}
                  className={
                    "text-sm px-3 py-2 rounded border text-left disabled:opacity-60 " +
                    (gamePicks[g.id] === team ? "bg-[var(--accent)] border-[var(--accent)] text-[var(--accent-text)] font-semibold" : "border-[var(--highlight)]/60 hover:border-[var(--accent-hover)]")
                  }
                >
                  {team}
                </button>
              ))}
            </div>
            {g.status === "final" && (
              <div className="mt-2 text-xs text-[var(--text-soft)]">
                Eindstand: {g.away_team} {g.away_score} – {g.home_score} {g.home_team}
              </div>
            )}
          </div>
        ))}
      </div>

      {!locked && (
        <button onClick={submit} className="mt-5 w-full bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-[var(--accent-text)] font-semibold text-sm py-2.5 rounded flex items-center justify-center gap-2">
          <Check size={16} />
          Picks opslaan
        </button>
      )}
    </div>
  );
}

function PlayerGate({ players, onRegister, onLogin, showToast }) {
  const [mode, setMode] = useState(players.length ? "login" : "register");

  if (mode === "register") {
    return (
      <div>
        <RegisterForm onRegister={onRegister} />
        {players.length > 0 && (
          <button onClick={() => setMode("login")} className="mt-3 text-xs text-[var(--text-soft)] hover:text-[var(--accent)] underline">
            Ik ben al geregistreerd
          </button>
        )}
      </div>
    );
  }

  return (
    <div>
      <LoginForm players={players} onLogin={onLogin} showToast={showToast} />
      <button onClick={() => setMode("register")} className="mt-3 text-xs text-[var(--text-soft)] hover:text-[var(--accent)] underline">
        Nieuwe speler? Meld je hier aan
      </button>
    </div>
  );
}

function LoginForm({ players, onLogin, showToast }) {
  const [playerId, setPlayerId] = useState(players[0]?.id || "");
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  function submit() {
    const player = players.find((p) => p.id === playerId);
    if (!player) return;
    if (player.pin && player.pin !== pin) {
      setError("Foute pincode.");
      return;
    }
    onLogin(player.id);
    showToast(`Welkom terug, ${player.name}!`);
  }

  return (
    <div className="border border-[var(--highlight-soft)] rounded-md p-5 bg-[var(--bg-panel)]/60 space-y-4">
      <h2 style={{ fontFamily: "'Bebas Neue', sans-serif" }} className="text-2xl text-[var(--accent)] flex items-center gap-2">
        <LogIn size={20} /> Inloggen
      </h2>
      <div>
        <label className="text-xs text-[var(--text-soft)]">Wie ben jij?</label>
        <select value={playerId} onChange={(e) => setPlayerId(e.target.value)} className="w-full mt-1 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm">
          {players.map((p) => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>
      </div>
      <div>
        <label className="text-xs text-[var(--text-soft)]">Pincode</label>
        <input
          type="password"
          value={pin}
          onChange={(e) => setPin(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          className="w-full mt-1 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm"
          placeholder="4 cijfers"
        />
      </div>
      {error && <p className="text-red-400 text-xs">{error}</p>}
      <button onClick={submit} className="w-full bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-[var(--accent-text)] font-semibold text-sm py-2.5 rounded">
        Inloggen
      </button>
    </div>
  );
}

function RegisterForm({ onRegister }) {
  const [name, setName] = useState("");
  const [championshipTeam, setChampionshipTeam] = useState("");
  const [rootingTeam, setRootingTeam] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  function submit() {
    if (!name.trim() || !championshipTeam || !rootingTeam || pin.trim().length !== 4) {
      setError("Vul je naam, beide teams en een pincode van 4 cijfers in.");
      return;
    }
    onRegister({ name: name.trim(), championshipTeam, rootingTeam, pin: pin.trim() });
  }

  return (
    <div className="border border-[var(--highlight-soft)] rounded-md p-5 bg-[var(--bg-panel)]/60 space-y-4">
      <h2 style={{ fontFamily: "'Bebas Neue', sans-serif" }} className="text-2xl text-[var(--accent)]">Meld je aan</h2>
      <p className="text-sm text-[var(--text-soft)]">
        Kies je naam, je championship team, je rooting team en een pincode van 4 cijfers zodat niemand anders voor jou kan kiezen.
      </p>
      <div>
        <label className="text-xs text-[var(--text-soft)]">Naam</label>
        <input value={name} onChange={(e) => setName(e.target.value)} className="w-full mt-1 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm" placeholder="Bv. Niels" />
      </div>
      <div>
        <label className="text-xs text-[var(--text-soft)]">Championship team</label>
        <select value={championshipTeam} onChange={(e) => setChampionshipTeam(e.target.value)} className="w-full mt-1 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm">
          <option value="">Kies een team…</option>
          {TEAMS.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>
      <div>
        <label className="text-xs text-[var(--text-soft)]">Rooting team</label>
        <select value={rootingTeam} onChange={(e) => setRootingTeam(e.target.value)} className="w-full mt-1 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm">
          <option value="">Kies een team…</option>
          {TEAMS.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>
      <div>
        <label className="text-xs text-[var(--text-soft)]">Pincode (4 cijfers)</label>
        <input
          type="password"
          value={pin}
          onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
          className="w-full mt-1 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm"
          placeholder="Bv. 1234"
        />
      </div>
      {error && <p className="text-red-400 text-xs">{error}</p>}
      <button onClick={submit} className="w-full bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-[var(--accent-text)] font-semibold text-sm py-2.5 rounded">
        Aanmelden
      </button>
    </div>
  );
}

/* ---------------------------------------------------------------
   Stand (leaderboard) tab
--------------------------------------------------------------- */

/* ---------------------------------------------------------------
   Overzicht tab — wie koos wat, pas zichtbaar na de deadline
--------------------------------------------------------------- */

function OverzichtTab({ week, weekGames, weekNum, players, picks }) {
  if (!week || weekGames.length === 0) {
    return <EmptyState title="Geen wedstrijden voor deze week" body="Er is nog niets om te tonen." />;
  }

  const locked = isLocked(week);
  const weekPicks = picks.filter((p) => p.week_num === weekNum);
  const submittedPlayerIds = new Set(weekPicks.map((p) => p.player_id));

  if (!locked) {
    return (
      <div className="space-y-4">
        <div className="border border-[var(--highlight-soft)] rounded-md p-4 bg-[var(--bg-panel)]/60 flex items-center gap-2 text-sm text-[var(--text-soft)]">
          <EyeOff size={16} className="text-[var(--accent)] shrink-0" />
          Ieders keuzes voor Week {weekNum} worden pas zichtbaar zodra de deadline ({fmtDeadline(week.deadline)}) verstreken is — zo kan niemand nog overschrijven van een ander.
        </div>
        <div className="text-sm text-[var(--text-soft)]">
          {submittedPlayerIds.size} van {players.length} speler(s) hebben hun picks al ingediend.
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm border border-[var(--highlight-soft)] rounded-md overflow-hidden">
        <thead className="bg-[var(--bg-panel)]/90 text-[var(--text-soft)] text-xs uppercase tracking-wide">
          <tr>
            <th className="text-left px-3 py-2">Wedstrijd</th>
            <th className="text-left px-3 py-2">Datum/uur</th>
            {players.map((p) => (
              <th key={p.id} className="text-left px-3 py-2">{p.name}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {weekGames.map((g, idx) => (
            <tr key={g.id} className="border-t border-[var(--highlight-soft)]">
              <td className="px-3 py-2 text-[var(--text-soft)] whitespace-nowrap">
                {idx + 1}. {g.away_team.split(" ").slice(-1)} @ {g.home_team.split(" ").slice(-1)}
                {g.auto_double && <Flame size={12} className="inline ml-1 text-[var(--accent)]" title="Automatische double point game" />}
              </td>
              <td className="px-3 py-2 text-[var(--text-soft)] text-xs whitespace-nowrap">
                {fmtKickoff(g.commence_time) || "–"}
              </td>
              {players.map((p) => {
                const pick = weekPicks.find((x) => x.player_id === p.id && x.game_id === g.id);
                return (
                  <td key={p.id} className="px-3 py-2">
                    {pick ? (
                      <span className="flex items-center gap-1">
                        {pick.picked_team.split(" ").slice(-1)}
                        {pick.is_double && <Flame size={12} className="text-[var(--accent)]" />}
                      </span>
                    ) : (
                      <span className="text-[var(--text-soft)]">–</span>
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ---------------------------------------------------------------
   Punten tab — gedetailleerde puntentelling per speler, per week
--------------------------------------------------------------- */

const ROOTING_LABELS = { win: "Gewonnen", loss: "Verloren", tie: "Gelijk", bye: "Bye-week" };

function PuntenTab({ week, weekGames, weekNum, players, me, picks, rootingResults }) {
  const locked = isLocked(week);
  const selectablePlayers = locked ? players : me ? [me] : [];
  const [selectedId, setSelectedId] = useState(me?.id || players[0]?.id || "");

  useEffect(() => {
    if (!locked && me) setSelectedId(me.id);
  }, [locked, me?.id]);

  if (!week || weekGames.length === 0) {
    return <EmptyState title="Geen wedstrijden voor deze week" body="Er is nog niets om te tonen." />;
  }

  if (selectablePlayers.length === 0) {
    return (
      <EmptyState
        title="Nog niet beschikbaar"
        body={locked ? "Nog geen spelers aangemeld." : "Meld je eerst aan via Picks om je puntentelling te zien."}
      />
    );
  }

  const player = players.find((p) => p.id === selectedId) || selectablePlayers[0];
  const playerPicks = picks.filter((p) => p.week_num === weekNum && p.player_id === player.id);

  let total = 0;
  const rows = weekGames.map((g, idx) => {
    const pick = playerPicks.find((p) => p.game_id === g.id);
    const pts = pick
      ? computeGamePoints(pick.picked_team, g, doubleCountForGame(picks, g))
      : null;
    if (pts !== null) total += pts;
    return { idx, game: g, pick, pts };
  });

  const rooting = rootingResults.find((r) => r.week_num === weekNum && r.team === player.rooting_team);
  let rootingPts = null;
  if (rooting?.outcome === "win") rootingPts = 1;
  else if (rooting?.outcome === "loss") rootingPts = -1;
  else if (rooting?.outcome === "tie" || rooting?.outcome === "bye") rootingPts = 0;
  if (rootingPts !== null) total += rootingPts;

  return (
    <div>
      {!locked && (
        <div className="mb-4 flex items-center gap-2 bg-[var(--bg-panel)]/60 border border-[var(--highlight-soft)] rounded px-3 py-2 text-sm text-[var(--text-soft)]">
          <EyeOff size={16} className="text-[var(--accent)] shrink-0" />
          Je ziet nu enkel je eigen puntentelling — die van anderen wordt zichtbaar na de deadline van deze week.
        </div>
      )}

      {locked && players.length > 1 && (
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(e.target.value)}
          className="mb-4 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm"
        >
          {players.map((p) => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm border border-[var(--highlight-soft)] rounded-md overflow-hidden min-w-[480px]">
          <thead className="bg-[var(--bg-panel)]/90 text-[var(--text-soft)] text-xs uppercase tracking-wide">
            <tr>
              <th className="text-left px-3 py-2">Wedstrijd</th>
              <th className="text-left px-3 py-2">Uitslag</th>
              <th className="text-left px-3 py-2">Pick</th>
              <th className="text-right px-3 py-2">Punten</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(({ idx, game, pick, pts }) => (
              <tr key={game.id} className="border-t border-[var(--highlight-soft)]">
                <td className="px-3 py-2 text-[var(--text-strong)]">
                  Wedstrijd {idx + 1}: {game.away_team} @ {game.home_team}
                </td>
                <td className="px-3 py-2 text-[var(--text-soft)]">
                  {game.status === "final" ? `${game.away_score} – ${game.home_score}` : "nog te spelen"}
                </td>
                <td className="px-3 py-2">
                  {pick ? (
                    <span className="flex items-center gap-1">
                      {pick.picked_team}
                      {/* Vóór de deadline mag enkel je eigen DPG-keuze zichtbaar zijn —
                          nooit of een ANDERE speler deze wedstrijd al dubbel zette,
                          want dat verklapt info over nog niet-vrijgegeven picks. */}
                      {(pick.is_double || game.auto_double || (locked && doubleCountForGame(picks, game) > 0)) && (
                        <span
                          className="flex items-center gap-0.5 text-[var(--accent)]"
                          title={
                            game.auto_double
                              ? "Deze wedstrijd is een automatische double point game voor iedereen"
                              : pick.is_double
                              ? "Jij hebt hier je eigen double point game op gezet"
                              : "Een andere speler zette hier zijn double point game op — deze wedstrijd telt daardoor ook voor jou dubbel"
                          }
                        >
                          <Flame size={12} />
                          x{Math.pow(2, locked ? doubleCountForGame(picks, game) : (game.auto_double ? 1 : 0) + (pick.is_double ? 1 : 0))}
                        </span>
                      )}
                    </span>
                  ) : (
                    <span className="text-[var(--text-soft)]">geen pick</span>
                  )}
                </td>
                <td className="px-3 py-2 text-right font-medium text-[var(--text-strong)]">{pts === null ? "–" : pts}</td>
              </tr>
            ))}
            <tr className="border-t border-[var(--highlight-soft)] bg-[var(--bg-panel)]/40">
              <td className="px-3 py-2 text-[var(--text-strong)]">Rooting team ({player.rooting_team})</td>
              <td className="px-3 py-2 text-[var(--text-soft)]">{rooting ? ROOTING_LABELS[rooting.outcome] : "nog niet bekend"}</td>
              <td className="px-3 py-2"></td>
              <td className="px-3 py-2 text-right font-medium text-[var(--text-strong)]">
                {rootingPts === null ? "–" : rootingPts > 0 ? `+${rootingPts}` : rootingPts}
              </td>
            </tr>
            <tr className="border-t border-[var(--highlight)]/60">
              <td colSpan={3} className="px-3 py-2 font-semibold text-[var(--accent)]">Totaal deze week</td>
              <td className="px-3 py-2 text-right font-bold text-[var(--accent)]">{total}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StandTab({ players, weeks, games, picks, rootingResults }) {
  if (players.length === 0) {
    return <EmptyState title="Nog geen spelers" body="Zodra iemand zich aanmeldt via de Picks-tab, verschijnt hier de stand." />;
  }

  const rows = players.map((player) => {
    let total = 0;
    for (const week of weeks) {
      const gamesOfWeek = games.filter((g) => g.week_num === week.week_num);
      const myPicks = picks.filter((p) => p.week_num === week.week_num && p.player_id === player.id);
      for (const pick of myPicks) {
        const game = gamesOfWeek.find((g) => g.id === pick.game_id);
        if (!game) continue;
        const pts = computeGamePoints(
          pick.picked_team,
          game,
          doubleCountForGame(picks, game)
        );
        if (pts !== null) total += pts;
      }
      const rooting = rootingResults.find((r) => r.week_num === week.week_num && r.team === player.rooting_team);
      if (rooting?.outcome === "win") total += 1;
      else if (rooting?.outcome === "loss") total -= 1;
    }
    return { player, total };
  });

  rows.sort((a, b) => b.total - a.total);

  return (
    <div>
      <div className="border border-[var(--highlight-soft)] rounded-md overflow-x-auto">
        <table className="w-full text-sm min-w-[420px]">
          <thead className="bg-[var(--bg-panel)]/90 text-[var(--text-soft)] text-xs uppercase tracking-wide">
            <tr>
              <th className="text-left px-3 py-2">#</th>
              <th className="text-left px-3 py-2">Speler</th>
              <th className="text-left px-3 py-2">Rooting team</th>
              <th className="text-right px-3 py-2">Punten</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r.player.id} className="border-t border-[var(--highlight-soft)]">
                <td className="px-3 py-2 text-[var(--text-soft)]">{i + 1}</td>
                <td className="px-3 py-2 flex items-center gap-1.5">
                  {i === 0 && <Trophy size={14} className="text-[var(--accent)]" />}
                  {r.player.name}
                </td>
                <td className="px-3 py-2 text-[var(--text-soft)]">{r.player.rooting_team}</td>
                <td className="px-3 py-2 text-right font-semibold text-[var(--text-strong)]">{r.total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {rows.length >= 2 && (
        <div className="mt-4 grid sm:grid-cols-3 gap-3 text-xs text-[var(--text-soft)]">
          <div className="border border-[var(--highlight-soft)] rounded p-3 flex items-center gap-2">
            <Trophy size={16} className="text-[var(--accent)]" />
            <span><span className="text-[var(--text-strong)] font-medium">{rows[0].player.name}</span> is voorlopig "King of the NFL".</span>
          </div>
          <div className="border border-[var(--highlight-soft)] rounded p-3 flex items-center gap-2">
            <Beer size={16} className="text-[var(--accent)]" />
            <span><span className="text-[var(--text-strong)] font-medium">{rows[1].player.name}</span> voorziet voorlopig de drank.</span>
          </div>
          <div className="border border-[var(--highlight-soft)] rounded p-3 flex items-center gap-2">
            <UtensilsCrossed size={16} className="text-[var(--accent)]" />
            <span>
              <span className="text-[var(--text-strong)] font-medium">{rows[rows.length - (rows.length >= 3 ? 2 : 1)].player.name}</span>{" "}
              {rows.length >= 3 ? "verzorgt voorlopig het vlees" : "organiseert voorlopig de BBQ"}.
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------
   Reglement tab
--------------------------------------------------------------- */

function ReglementTab() {
  return (
    <div className="space-y-4 text-sm text-[var(--text-strong)] leading-relaxed">
      <Section title="Puntentelling per wedstrijd">
        <ul className="list-disc pl-5 space-y-1">
          <li>Winst met 10 punten verschil of meer: 4 punten</li>
          <li>Winst met minder dan 10 punten verschil: 2 punten</li>
          <li>Verlies met minder dan 10 punten verschil: 1 punt</li>
          <li>Verlies met 10 punten verschil of meer: 0 punten</li>
        </ul>
      </Section>
      <Section title="Rooting team">
        Wint je rooting team die week, dan krijg je 1 extra punt. Verliest het, dan verlies je 1 punt. Bij gelijkspel of een bye-week verandert er niets. Dit wordt automatisch bijgehouden.
      </Section>
      <Section title="Dubbele-puntenwedstrijden">
        Je krijgt 3 dubbele-puntenkaarten: één in te zetten tussen week 1 en 6, één tussen week 7 en 12, en één tussen week 13 en 18. Zet je hem niet op tijd in, dan vervalt hij. Je moet eerst al je picks voor die week hebben doorgegeven voordat je een dubbele-puntenwedstrijd mag kiezen.
      </Section>
      <Section title="Automatisering">
        Elke woensdagochtend worden de 5 spannendste wedstrijden (kleinste spread) automatisch toegevoegd. Zodra een wedstrijd is afgelopen, wordt de uitslag automatisch opgehaald en worden de punten meteen herberekend.
      </Section>
      <Section title="Eindstand & rechten/plichten">
        <ul className="list-disc pl-5 space-y-1">
          <li>Winnaar: officieel "King of the NFL", wordt gehuldigd op de afsluitende BBQ.</li>
          <li>Tweede plaats: verzorgt de drank op de BBQ.</li>
          <li>Voorlaatste plaats: verzorgt het feestmaal (vlees en dergelijke).</li>
          <li>Laatste plaats: organiseert de volledige afsluitende BBQ.</li>
        </ul>
      </Section>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="border border-[var(--highlight-soft)] rounded-md p-4 bg-[var(--bg-panel)]/60">
      <h3 className="text-[var(--accent)] font-semibold mb-1.5">{title}</h3>
      <div>{children}</div>
    </div>
  );
}

/* ---------------------------------------------------------------
   Beheer (admin) tab — nu vooral voor manuele correcties, want
   wedstrijden en uitslagen komen automatisch binnen.
--------------------------------------------------------------- */

function BeheerTab({ weeks, games, players, picks, activeWeek, rootingTeams, rootingResults, onAddWeek, onSaveResult, onSaveRooting, onRemovePlayer, showToast }) {
  const [newWeekNum, setNewWeekNum] = useState(weeks.length ? Math.max(...weeks.map((w) => w.week_num)) + 1 : 1);
  const [deadline, setDeadline] = useState("");
  const [draftGames, setDraftGames] = useState([{ home: "", away: "", spread: "" }]);

  function addDraftGame() {
    if (draftGames.length >= 6) return;
    setDraftGames([...draftGames, { home: "", away: "", spread: "" }]);
  }
  function removeDraftGame(idx) {
    setDraftGames(draftGames.filter((_, i) => i !== idx));
  }
  function updateDraftGame(idx, field, value) {
    setDraftGames(draftGames.map((g, i) => (i === idx ? { ...g, [field]: value } : g)));
  }

  function saveWeek() {
    if (!newWeekNum || draftGames.some((g) => !g.home || !g.away)) {
      showToast("Vul voor elke wedstrijd een thuis- en uitploeg in.");
      return;
    }
    onAddWeek(newWeekNum, deadline, draftGames);
    setDraftGames([{ home: "", away: "", spread: "" }]);
  }

  const sortedWeeks = [...weeks].sort((a, b) => b.week_num - a.week_num);

  const currentPeriod = PERIODS.find((p) => activeWeek >= p.min && activeWeek <= p.max) || PERIODS[0];
  const dpgOverview = players.map((player) => {
    const pick = picks.find(
      (p) =>
        p.player_id === player.id &&
        p.is_double &&
        p.week_num >= currentPeriod.min &&
        p.week_num <= currentPeriod.max
    );
    const game = pick ? games.find((g) => g.id === pick.game_id) : null;
    return { player, pick, game };
  });

  return (
    <div className="space-y-8">
      <div className="border border-[var(--accent-border)] rounded-md p-4 bg-[var(--accent-border)]/20 text-sm text-[var(--accent-hover)]">
        Wedstrijden en uitslagen komen normaal automatisch binnen (elke woensdag, en na elke wedstrijd).
        Gebruik onderstaande formulieren enkel als noodgreep — bv. als de automatische taak een week heeft
        gemist, of een uitslag verkeerd staat.
      </div>

      <div className="border border-[var(--highlight-soft)] rounded-md p-4 bg-[var(--bg-panel)]/60">
        <h3 className="text-[var(--accent)] font-semibold mb-1">
          Double point games — {currentPeriod.label}
        </h3>
        <p className="text-xs text-[var(--text-soft)] mb-3">
          Wie z'n DPG al ingezet heeft in de lopende periode (op basis van week {activeWeek}).
        </p>
        {players.length === 0 ? (
          <p className="text-sm text-[var(--text-soft)]">Nog geen spelers aangemeld.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[var(--text-soft)] text-xs uppercase tracking-wide">
                <tr>
                  <th className="text-left py-1.5 pr-3">Speler</th>
                  <th className="text-left py-1.5 pr-3">Status</th>
                  <th className="text-left py-1.5">Wedstrijd</th>
                </tr>
              </thead>
              <tbody>
                {dpgOverview.map(({ player, pick, game }) => (
                  <tr key={player.id} className="border-t border-[var(--highlight-soft)]/60">
                    <td className="py-1.5 pr-3 text-[var(--text-strong)]">{player.name}</td>
                    <td className="py-1.5 pr-3">
                      {pick ? (
                        <span className="inline-flex items-center gap-1 text-[var(--accent)]">
                          <Flame size={12} /> ingezet (week {pick.week_num})
                        </span>
                      ) : (
                        <span className="text-[var(--text-soft)]">nog niet ingezet</span>
                      )}
                    </td>
                    <td className="py-1.5 text-[var(--text-soft)]">
                      {game ? `${game.away_team} @ ${game.home_team}` : "–"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="border border-[var(--highlight-soft)] rounded-md p-4 bg-[var(--bg-panel)]/60">
        <h3 className="text-[var(--accent)] font-semibold mb-3">Week handmatig toevoegen</h3>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <div>
            <label className="text-xs text-[var(--text-soft)]">Weeknummer</label>
            <input type="number" value={newWeekNum} onChange={(e) => setNewWeekNum(e.target.value)} className="w-full mt-1 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="text-xs text-[var(--text-soft)]">Deadline (1e kickoff)</label>
            <input type="datetime-local" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="w-full mt-1 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-3 py-2 text-sm" />
          </div>
        </div>
        <div className="space-y-2">
          {draftGames.map((g, idx) => (
            <div key={idx} className="flex flex-wrap gap-2 items-center">
              <select value={g.away} onChange={(e) => updateDraftGame(idx, "away", e.target.value)} className="flex-1 min-w-[140px] bg-emerald-950 border border-[var(--highlight)]/60 rounded px-2 py-1.5 text-xs">
                <option value="">Uitploeg…</option>
                {TEAMS.map((t) => <option key={t}>{t}</option>)}
              </select>
              <span className="text-[var(--text-soft)] text-xs">@</span>
              <select value={g.home} onChange={(e) => updateDraftGame(idx, "home", e.target.value)} className="flex-1 min-w-[140px] bg-emerald-950 border border-[var(--highlight)]/60 rounded px-2 py-1.5 text-xs">
                <option value="">Thuisploeg…</option>
                {TEAMS.map((t) => <option key={t}>{t}</option>)}
              </select>
              <input placeholder="Bv. Cowboys -2.5" value={g.spread} onChange={(e) => updateDraftGame(idx, "spread", e.target.value)} className="w-28 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-2 py-1.5 text-xs" />
              <button onClick={() => removeDraftGame(idx)} className="text-[var(--text-soft)] hover:text-red-400">
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
        <button onClick={addDraftGame} disabled={draftGames.length >= 6} className="mt-2 text-xs text-[var(--accent)] hover:text-[var(--accent-hover)] disabled:opacity-30">
          + Wedstrijd toevoegen (max. 6)
        </button>
        <button onClick={saveWeek} className="mt-4 w-full bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-[var(--accent-text)] font-semibold text-sm py-2 rounded">
          Week opslaan
        </button>
      </div>

      {sortedWeeks.map((wk) => (
        <div key={wk.week_num} className="border border-[var(--highlight-soft)] rounded-md p-4 bg-[var(--bg-panel)]/60">
          <h3 className="text-[var(--accent)] font-semibold mb-3">Week {wk.week_num}</h3>
          <div className="space-y-2">
            {games.filter((g) => g.week_num === wk.week_num).map((g) => (
              <ResultRow key={g.id} game={g} onSave={onSaveResult} />
            ))}
          </div>

          {rootingTeams.length > 0 && (
            <>
              <h4 className="text-[var(--text-soft)] text-xs uppercase tracking-wide mt-4 mb-2">Rooting team-uitslagen</h4>
              <div className="space-y-1.5">
                {rootingTeams.map((team) => {
                  const current = rootingResults.find((r) => r.week_num === wk.week_num && r.team === team);
                  return (
                    <div key={team} className="flex items-center justify-between text-sm">
                      <span>{team}</span>
                      <select
                        value={current?.outcome || ""}
                        onChange={(e) => onSaveRooting(wk.week_num, team, e.target.value)}
                        className="bg-emerald-950 border border-[var(--highlight)]/60 rounded px-2 py-1 text-xs"
                      >
                        <option value="">– (nog niet bekend)</option>
                        <option value="win">Gewonnen (+1)</option>
                        <option value="loss">Verloren (-1)</option>
                        <option value="tie">Gelijk (0)</option>
                        <option value="bye">Bye-week (0)</option>
                      </select>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      ))}

      <div className="border border-[var(--highlight-soft)] rounded-md p-4 bg-[var(--bg-panel)]/60">
        <h3 className="text-[var(--accent)] font-semibold mb-3">Spelers</h3>
        {players.length === 0 && <p className="text-sm text-[var(--text-soft)]">Nog niemand aangemeld.</p>}
        <div className="space-y-1.5">
          {players.map((p) => (
            <div key={p.id} className="flex items-center justify-between text-sm">
              <span>
                {p.name}{" "}
                <span className="text-[var(--text-soft)] text-xs">
                  (championship: {p.championship_team}, rooting: {p.rooting_team})
                </span>
              </span>
              <button onClick={() => onRemovePlayer(p.id)} className="text-[var(--text-soft)] hover:text-red-400">
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ResultRow({ game, onSave }) {
  const [home, setHome] = useState(game.home_score ?? "");
  const [away, setAway] = useState(game.away_score ?? "");

  return (
    <div className="flex flex-wrap items-center gap-2 text-sm">
      <span className="flex-1 min-w-[120px] truncate">{game.away_team} @ {game.home_team}</span>
      <input type="number" value={away} onChange={(e) => setAway(e.target.value)} placeholder="Uit" className="w-16 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-2 py-1 text-xs" />
      <span className="text-[var(--text-soft)]">–</span>
      <input type="number" value={home} onChange={(e) => setHome(e.target.value)} placeholder="Thuis" className="w-16 bg-emerald-950 border border-[var(--highlight)]/60 rounded px-2 py-1 text-xs" />
      <button
        onClick={() => onSave(game.id, home, away)}
        disabled={home === "" || away === ""}
        className="text-xs px-2 py-1 rounded bg-[var(--accent)] text-[var(--accent-text)] font-semibold disabled:opacity-30"
      >
        Opslaan
      </button>
    </div>
  );
}

/* ---------------------------------------------------------------
   Small shared bits
--------------------------------------------------------------- */

function EmptyState({ title, body }) {
  return (
    <div className="border border-dashed border-[var(--highlight)]/60 rounded-md p-8 text-center">
      <h3 className="text-[var(--accent)] font-semibold mb-1">{title}</h3>
      <p className="text-sm text-[var(--text-soft)]">{body}</p>
    </div>
  );
}
